require 'rails_helper.rb'

feature "User adds a new item" do
    scenario "User successfully navigates to the new item page from the item listing page" do
        visit items_path    
        expect(page).to have_content("Listing items")
        click_link "New Item"
        expect(page).to have_content("New Item")
        expect(page).to have_field("item[ItemName]")
        expect(page).to have_field("item[Price]")
        expect(page).to have_field("item[Quantity]")
        expect(page).to have_field("item[Description]")
    end
    
    scenario "User successfully creates a new item" do
        visit new_item_path
        expect(page).to have_content("New Item")
        fill_in "item[ItemName]", with: "New Capybara Item"
        fill_in "item[Price]", with: "5.39"
        fill_in "item[Quantity]", with: "50"
        fill_in "item[Description]", with: "Capybara test item."
        click_button "Save Item"
        expect(page).to have_content("New Capybara Item")
        expect(page).to have_content("5.39")
        expect(page).to have_content("50")
        expect(page).to have_content("Capybara test item.")
    end
end
