require 'rails_helper.rb'

feature "As a user, admin, or employee, I want to view a Welcome page along with interactive links to different pages." do
    scenario "User successfully views welcome page" do
        visit welcome_index_path    
        find_link("Home").visible?
        find_link("View Items").visible?
        find_link("View Transactions").visible?
        find_link("About").visible?
        find_link("Contact").visible?
    end
end
