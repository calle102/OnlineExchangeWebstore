Rails.application.routes.draw do 
 
  
  get 'contact/index'

  get 'about/index'

  resources :items do
    member do
      get :add_to_carts
    end
  end
  
  resources :items
  resources :carts
  resources :about
  resources :contact
  
  

  #map.connect ":controller/:action/:id"
  
  get '/carts/:id/addto/:itemid', to: 'carts#addto'
  get '/carts/:id/removefrom/:itemid', to: 'carts#removefrom'
  
  get '/carts/selectcart/:itemid', to: 'carts#selectcart'
  
  get 'welcome/index'
  
  root 'welcome#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
