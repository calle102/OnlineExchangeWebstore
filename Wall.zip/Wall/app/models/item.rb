class Item < ApplicationRecord
    validates :ItemName, presence: true
    validates :Price, presence: true
    validates :Quantity, presence: true

    has_and_belongs_to_many :carts
end
   # def self.search(search)
   #  where("itemid LIKE ?, "%#{search}%) 
 #end