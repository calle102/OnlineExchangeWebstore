class CartsController < ApplicationController
    
    def show
        @cart = Cart.find(params[:id])
        @items = @cart.items
        @total=0
        @items.each do |current_item|
            @total = @total + current_item.Price
        end
    end
    
    def new
        
        @cart = Cart.new
    end
    
    def index
        
        @carts = Cart.all
    end
    
    def selectcart
        @carts = Cart.all
        @itemid = params[:itemid]
    end
    
    
    def addto
        
        @cart = Cart.find(params[:id])
        @item = Item.find(params[:itemid])
        @item.Quantity = @item.Quantity - 1
        @cart.items << @item
        #^^^ The Line In Question ^^^ #
        
        redirect_to cart_path(@cart)
    end
    
    def removefrom
        @cart = Cart.find(params[:id])
        @item = Item.find(params[:itemid])
        
        @item.Quantity = @item.Quantity + 1
        @cart.items.delete(Item.find(@item)) # Works, but removes every item with items id.
        
        #render :text => @itemsToRemove
        redirect_to cart_path(@cart)
    end
    
    def create
        
        @cart = Cart.new(cart_params)
        #@cart = session[:cart]
        if @cart.save
            redirect_to @cart
        else
            render 'new'
        end
    end
    
   # def make_active
        #session[:cart_id] = cart.id
   # end
    
    
    def update
       @cart = Cart.find(params[:id])
       if @cart.update(cart_params)
           redirect_to @cart
       else
           render 'edit'
       end
    end
    
    def edit
       
       # id = params[:itemid]
       # cart = session[:id]
       
       @cart = Cart.find(params[:id]) 
     
       
    end
    
    def destroy
       @cart = Cart.find(params[:id])
       @cart.destroy
       
       redirect_to carts_path
    end
end

private
    def cart_params
        # params.require(:cart).permit(:carID)
    end