class AddTransactionToItem < ActiveRecord::Migration[5.0]
  def change
  end
end
